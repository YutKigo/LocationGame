package jp.ac.ritsumei.ise.phy.exp2.is0691ve.locationgame;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ScoreActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_score);

        // スコアを受け取る
        int score = getIntent().getIntExtra("SCORE", 0);

        // スコアを表示
        TextView scoreTextView = findViewById(R.id.tvScore);
        scoreTextView.setText("Your Score: " + score);

        // 戻るボタンの処理
        Button btnBack = findViewById(R.id.btnBackToMain);
        btnBack.setOnClickListener(v -> {
            Intent intent = new Intent(ScoreActivity.this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish(); // ScoreActivity を終了
        });
    }
}